import {LRParser} from "@lezer/lr"

export declare const parser: LRParser
